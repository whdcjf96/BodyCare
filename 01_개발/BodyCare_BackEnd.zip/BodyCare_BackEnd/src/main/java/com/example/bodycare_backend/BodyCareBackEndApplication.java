package com.example.bodycare_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BodyCareBackEndApplication {

    public static void main(String[] args) {
        SpringApplication.run(BodyCareBackEndApplication.class, args);
    }

}
